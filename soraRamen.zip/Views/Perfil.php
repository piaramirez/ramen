<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $data['tag_page']; ?></title>
    
</head>
<body>
    
    <h1>Este es el Perfil</h1>
    <a href="home">Ini9cio</a>
    <div class="">

        <a href="Perfil/Reservación">Reservación</a>
        <a href="Menu/Bebidas">Pedidos</a>
        <a href="Perfil/Configuracion">Configuración</a>
    </div>
</body>
</html>