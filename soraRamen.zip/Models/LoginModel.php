<?php
class LoginModel{
    public function __construct(){
        //echo "Estamos dentro del controlador Login Model </br>";
    }
}