<?php
class MenuModel{
    public function __construct(){
        //echo "Estamos dentro del menuMopdel";
    }
    /**
     * Aquí vamos a crear las consultas para mandar a llamar la info de los 
     * platillos, postres y bebidas.
     */
}