<?php
//define("BASE_URL", "http://localhost/soraRamen/");
const BASE_URL = "http://localhost/soraRamen/";

//echo "Estamos dentro";
const DB_HOST = "localhost";
const DB_NAME = "soraRamen";
const DB_USER =   "piaRam";
const DB_PASSWORD = "17A07n95t";
const DB_CHARSET = "charset=utf8";
const SPD =  ",";
const SPM = ".";